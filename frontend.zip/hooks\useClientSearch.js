// Custom hook para manejar la lógica de búsqueda de clientes
import { useState, useEffect } from 'react';
import { clientsService } from '../services/clientsService';

export const useClientSearch = () => {
    const [client, setClient] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (searchQuery.length >= 2) {
            setLoading(true);
            clientsService.searchClients(searchQuery)
                .then(results => {
                    setResults(results);
                    setLoading(false);
                })
                .catch(err => {
                    console.error('Error searching clients:', err);
                    setLoading(false);
                });
        } else {
            setResults([]);
        }
    }, [searchQuery]);

    const selectClient = (selectedClient) => {
        setClient(selectedClient);
        setSearchQuery('');
        setResults([]);
    };

    const clearClient = () => {
        setClient(null);
    };

    return {
        client,
        searchQuery,
        results,
        loading,
        setSearchQuery,
        selectClient,
        clearClient
    };
};

export default useClientSearch;
