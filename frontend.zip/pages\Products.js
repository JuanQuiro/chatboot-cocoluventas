import React, { useState, useEffect, useCallback } from 'react';
import CreateProductModal from '../components/CreateProductModal';
import './Products.css';

const Products = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchProducts = useCallback(async () => {
    try {
      const response = await fetch('/api/products');
      const data = await response.json();
      if (data.success) {
        setProducts(data.data);
        setLoading(false);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  if (loading) {
    return <div className="loading">Cargando productos...</div>;
  }

  return (
    <div className="products-page">
      <div className="page-header">
        <div>
          <h2>📦 Catálogo de Productos</h2>
          <p>Total de productos: {products.length}</p>
        </div>
        <button className="btn-primary" onClick={() => setIsModalOpen(true)}>
          + Nuevo Producto
        </button>
      </div>

      <CreateProductModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onProductCreated={fetchProducts}
      />

      {products.length === 0 ? (
        <div className="empty-state">
          <p>No hay productos registrados. ¡Agrega uno nuevo!</p>
        </div>
      ) : (
        <div className="products-grid">
          {products.map((product) => (
            <div key={product.id} className="product-card">
              <div className="product-icon">{product.icon || '📦'}</div>
              <div className="product-header">
                <h3>{product.name}</h3>
                <span className="product-category">{product.category_id === 1 ? 'General' : 'Otro'}</span>
              </div>
              <div className="product-details">
                <div className="product-price">
                  <span className="price-label">Precio</span>
                  <span className="price-value">${product.precio_usd?.toFixed(2) || product.price?.toFixed(2) || '0.00'}</span>
                </div>
                <div className="product-stock">
                  <span className="stock-label">Stock</span>
                  <span className={`stock-value ${product.stock_actual > 0 ? 'in-stock' : 'out-of-stock'}`}>
                    {product.stock_actual || product.stock || 0} unidades
                  </span>
                </div>
              </div>
              <div className="product-footer">
                <span className="product-id">SKU: {product.sku}</span>
                <span className={`stock-indicator ${(product.stock_actual || product.stock) > 0 ? 'available' : 'unavailable'}`}>
                  {(product.stock_actual || product.stock) > 0 ? '● Disponible' : '● Sin stock'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Products;
