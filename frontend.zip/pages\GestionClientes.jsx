import React, { useState, useEffect } from 'react';
import { clientsService } from '../services/clientsService';
import DataTable from '../components/common/DataTable';
import SearchInput from '../components/common/SearchInput';
import './GestionClientes.css';

const GestionClientes = () => {
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [showForm, setShowForm] = useState(false);
    const [editingClient, setEditingClient] = useState(null);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        address: '',
        notes: ''
    });

    useEffect(() => {
        loadClients();
    }, [searchQuery]);

    const loadClients = async () => {
        setLoading(true);
        try {
            const data = await clientsService.getClients({ search: searchQuery });
            setClients(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error('Error loading clients:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editingClient) {
                await clientsService.updateClient(editingClient.id, formData);
                alert('Cliente actualizado exitosamente');
            } else {
                await clientsService.createClient(formData);
                alert('Cliente creado exitosamente');
            }
            setShowForm(false);
            setEditingClient(null);
            setFormData({ name: '', email: '', phone: '', address: '', notes: '' });
            loadClients();
        } catch (error) {
            console.error('Error saving client:', error);
            alert('Error al guardar el cliente');
        }
    };

    const handleEdit = (client) => {
        setEditingClient(client);
        setFormData(client);
        setShowForm(true);
    };

    const handleDelete = async (clientId) => {
        if (!window.confirm('¿Estás seguro de eliminar este cliente?')) return;
        try {
            await clientsService.deleteClient(clientId);
            alert('Cliente eliminado exitosamente');
            loadClients();
        } catch (error) {
            console.error('Error deleting client:', error);
            alert('Error al eliminar el cliente');
        }
    };

    const columns = [
        { key: 'name', label: 'Nombre', sortable: true },
        { key: 'email', label: 'Email', sortable: true },
        { key: 'phone', label: 'Teléfono', sortable: true },
        { key: 'address', label: 'Dirección' },
        {
            key: 'balance',
            label: 'Saldo',
            sortable: true,
            render: (value) => (
                <span className={value > 0 ? 'balance-positive' : 'balance-zero'}>
                    ${value?.toFixed(2) || '0.00'}
                </span>
            )
        }
    ];

    const renderActions = (client) => (
        <div className="client-actions">
            <button onClick={() => handleEdit(client)} className="btn-action btn-edit" title="Editar">
                ✏️
            </button>
            <button onClick={() => window.location.href = `/clients/${client.id}/history`} className="btn-action btn-view" title="Ver historial">
                📋
            </button>
            <button onClick={() => handleDelete(client.id)} className="btn-action btn-delete" title="Eliminar">
                🗑️
            </button>
        </div>
    );

    return (
        <div className="gestion-clientes-page">
            <div className="page-header">
                <div>
                    <h1>👥 Gestión de Clientes</h1>
                    <p>Administra todos los clientes del sistema</p>
                </div>
                <button
                    onClick={() => {
                        setShowForm(true);
                        setEditingClient(null);
                        setFormData({ name: '', email: '', phone: '', address: '', notes: '' });
                    }}
                    className="btn-primary"
                >
                    ➕ Nuevo Cliente
                </button>
            </div>

            {showForm && (
                <div className="modal-overlay" onClick={() => setShowForm(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <h2>{editingClient ? 'Editar Cliente' : 'Nuevo Cliente'}</h2>
                            <button onClick={() => setShowForm(false)} className="modal-close">✕</button>
                        </div>
                        <form onSubmit={handleSubmit} className="client-form">
                            <div className="form-group">
                                <label>Nombre *</label>
                                <input
                                    type="text"
                                    value={formData.name}
                                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                    required
                                    className="form-control"
                                />
                            </div>
                            <div className="form-row">
                                <div className="form-group">
                                    <label>Email</label>
                                    <input
                                        type="email"
                                        value={formData.email}
                                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                        className="form-control"
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Teléfono *</label>
                                    <input
                                        type="tel"
                                        value={formData.phone}
                                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                        required
                                        className="form-control"
                                    />
                                </div>
                            </div>
                            <div className="form-group">
                                <label>Dirección</label>
                                <input
                                    type="text"
                                    value={formData.address}
                                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                                    className="form-control"
                                />
                            </div>
                            <div className="form-group">
                                <label>Notas</label>
                                <textarea
                                    value={formData.notes}
                                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                                    className="form-control"
                                    rows="3"
                                />
                            </div>
                            <div className="form-actions">
                                <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">
                                    Cancelar
                                </button>
                                <button type="submit" className="btn-primary">
                                    {editingClient ? 'Actualizar' : 'Crear'} Cliente
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            <div className="filters-section">
                <SearchInput
                    placeholder="Buscar por nombre, email o teléfono..."
                    onSearch={setSearchQuery}
                    icon="🔍"
                />
            </div>

            <div className="clients-stats">
                <div className="stat-card">
                    <span className="stat-label">Total Clientes</span>
                    <span className="stat-value">{clients.length}</span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Con Saldo Pendiente</span>
                    <span className="stat-value warning">
                        {clients.filter(c => c.balance > 0).length}
                    </span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Saldo Total</span>
                    <span className="stat-value">
                        ${clients.reduce((sum, c) => sum + (c.balance || 0), 0).toFixed(2)}
                    </span>
                </div>
            </div>

            <DataTable
                columns={columns}
                data={clients}
                loading={loading}
                actions={renderActions}
                pagination={true}
                pageSize={15}
            />
        </div>
    );
};

export default GestionClientes;
