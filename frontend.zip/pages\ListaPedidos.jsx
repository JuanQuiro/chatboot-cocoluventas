import React, { useState, useEffect } from 'react';
import { ordersService } from '../services/salesService';
import DataTable from '../components/common/DataTable';
import SearchInput from '../components/common/SearchInput';
import StatusBadge from '../components/common/StatusBadge';
import './ListaPedidos.css';

const ListaPedidos = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');
    const [dateRange, setDateRange] = useState({ start: '', end: '' });

    useEffect(() => {
        loadOrders();
    }, [searchQuery, statusFilter, dateRange]);

    const loadOrders = async () => {
        setLoading(true);
        try {
            const filters = {
                search: searchQuery,
                status: statusFilter !== 'all' ? statusFilter : undefined,
                startDate: dateRange.start || undefined,
                endDate: dateRange.end || undefined
            };

            const data = await ordersService.getOrders(filters);
            // Ensure data is always an array
            setOrders(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error('Error loading orders:', error);
            setOrders([]); // Set empty array on error
            alert('Error al cargar los pedidos');
        } finally {
            setLoading(false);
        }
    };

    const handleStatusChange = async (orderId, newStatus) => {
        try {
            await ordersService.updateOrderStatus(orderId, newStatus);
            loadOrders();
            alert('Estado actualizado exitosamente');
        } catch (error) {
            console.error('Error updating status:', error);
            alert('Error al actualizar el estado');
        }
    };

    const handleDelete = async (orderId) => {
        if (!window.confirm('¿Estás seguro de eliminar este pedido?')) {
            return;
        }

        try {
            await ordersService.deleteOrder(orderId);
            loadOrders();
            alert('Pedido eliminado exitosamente');
        } catch (error) {
            console.error('Error deleting order:', error);
            alert('Error al eliminar el pedido');
        }
    };

    const handleExport = async () => {
        try {
            const blob = await ordersService.exportOrders({
                search: searchQuery,
                status: statusFilter !== 'all' ? statusFilter : undefined,
                startDate: dateRange.start || undefined,
                endDate: dateRange.end || undefined
            });

            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `pedidos_${new Date().toISOString().split('T')[0]}.xlsx`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error exporting orders:', error);
            alert('Error al exportar los pedidos');
        }
    };

    const columns = [
        {
            key: 'id',
            label: 'ID',
            sortable: true,
            render: (value) => `#${value}`
        },
        {
            key: 'date',
            label: 'Fecha',
            sortable: true,
            render: (value) => new Date(value).toLocaleDateString()
        },
        {
            key: 'client',
            label: 'Cliente',
            sortable: true,
            render: (value) => value?.name || 'N/A'
        },
        {
            key: 'items',
            label: 'Productos',
            render: (value) => `${value?.length || 0} items`
        },
        {
            key: 'total',
            label: 'Total',
            sortable: true,
            render: (value) => `$${value?.toFixed(2) || '0.00'}`
        },
        {
            key: 'status',
            label: 'Estado',
            sortable: true,
            render: (value) => <StatusBadge status={value} />
        },
        {
            key: 'paymentMethod',
            label: 'Pago',
            render: (value) => value || 'N/A'
        }
    ];

    const renderActions = (order) => (
        <div className="order-actions">
            <button
                onClick={() => window.location.href = `/orders/${order.id}`}
                className="btn-action btn-view"
                title="Ver detalles"
            >
                👁️
            </button>
            <button
                onClick={() => window.location.href = `/orders/${order.id}/edit`}
                className="btn-action btn-edit"
                title="Editar"
            >
                ✏️
            </button>
            <select
                value={order.status}
                onChange={(e) => handleStatusChange(order.id, e.target.value)}
                className="status-select"
                title="Cambiar estado"
            >
                <option value="pendiente">Pendiente</option>
                <option value="en proceso">En Proceso</option>
                <option value="completado">Completado</option>
                <option value="cancelado">Cancelado</option>
            </select>
            <button
                onClick={() => handleDelete(order.id)}
                className="btn-action btn-delete"
                title="Eliminar"
            >
                🗑️
            </button>
        </div>
    );

    return (
        <div className="lista-pedidos-page">
            <div className="page-header">
                <div>
                    <h1>📋 Lista de Pedidos</h1>
                    <p>Gestiona todos los pedidos del sistema</p>
                </div>
                <button
                    onClick={() => window.location.href = '/crear-venta'}
                    className="btn-primary"
                >
                    ➕ Nueva Venta
                </button>
            </div>

            <div className="filters-section">
                <SearchInput
                    placeholder="Buscar por ID, cliente, producto..."
                    onSearch={setSearchQuery}
                    icon="🔍"
                />

                <div className="filter-group">
                    <label>Estado:</label>
                    <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="filter-select"
                    >
                        <option value="all">Todos</option>
                        <option value="pendiente">Pendiente</option>
                        <option value="en proceso">En Proceso</option>
                        <option value="completado">Completado</option>
                        <option value="cancelado">Cancelado</option>
                    </select>
                </div>

                <div className="filter-group">
                    <label>Desde:</label>
                    <input
                        type="date"
                        value={dateRange.start}
                        onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                        className="filter-input"
                    />
                </div>

                <div className="filter-group">
                    <label>Hasta:</label>
                    <input
                        type="date"
                        value={dateRange.end}
                        onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                        className="filter-input"
                    />
                </div>

                <button
                    onClick={handleExport}
                    className="btn-secondary"
                    title="Exportar a Excel"
                >
                    📊 Exportar
                </button>
            </div>

            <div className="orders-stats">
                <div className="stat-card">
                    <span className="stat-label">Total Pedidos</span>
                    <span className="stat-value">{orders.length}</span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Pendientes</span>
                    <span className="stat-value warning">
                        {orders.filter(o => o.status === 'pendiente').length}
                    </span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Completados</span>
                    <span className="stat-value success">
                        {orders.filter(o => o.status === 'completado').length}
                    </span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Total Ventas</span>
                    <span className="stat-value">
                        ${orders.reduce((sum, o) => sum + (o.total || 0), 0).toFixed(2)}
                    </span>
                </div>
            </div>

            <DataTable
                columns={columns}
                data={orders}
                loading={loading}
                actions={renderActions}
                pagination={true}
                pageSize={15}
            />
        </div>
    );
};

export default ListaPedidos;
