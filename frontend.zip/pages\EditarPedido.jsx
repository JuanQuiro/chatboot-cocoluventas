import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ordersService } from '../services/salesService';
import { inventoryService } from '../services/inventoryService';
import SearchInput from '../components/common/SearchInput';
import { useToast } from '../components/common/Toast';
import './EditarPedido.css';

const EditarPedido = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const toast = useToast();

    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const [cart, setCart] = useState([]);
    const [productSearch, setProductSearch] = useState('');
    const [productResults, setProductResults] = useState([]);
    const [notes, setNotes] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('efectivo');

    useEffect(() => {
        loadOrder();
    }, [id]);

    useEffect(() => {
        if (productSearch.length >= 2) {
            inventoryService.searchProducts(productSearch)
                .then(results => setProductResults(results))
                .catch(err => console.error('Error searching products:', err));
        } else {
            setProductResults([]);
        }
    }, [productSearch]);

    const loadOrder = async () => {
        try {
            const data = await ordersService.getOrderById(id);
            setOrder(data);
            setCart(data.items || []);
            setNotes(data.notes || '');
            setPaymentMethod(data.paymentMethod || 'efectivo');
        } catch (error) {
            toast.error('Error al cargar el pedido');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const addToCart = (product) => {
        const existing = cart.find(item => item.productId === product.id);
        if (existing) {
            setCart(cart.map(item =>
                item.productId === product.id
                    ? { ...item, quantity: item.quantity + 1 }
                    : item
            ));
        } else {
            setCart([...cart, {
                productId: product.id,
                name: product.name,
                price: product.price,
                quantity: 1
            }]);
        }
        setProductSearch('');
        setProductResults([]);
    };

    const updateQuantity = (productId, quantity) => {
        if (quantity <= 0) {
            removeFromCart(productId);
        } else {
            setCart(cart.map(item =>
                item.productId === productId ? { ...item, quantity } : item
            ));
        }
    };

    const removeFromCart = (productId) => {
        setCart(cart.filter(item => item.productId !== productId));
    };

    const calculateTotal = () => {
        return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    };

    const handleSave = async () => {
        if (cart.length === 0) {
            toast.warning('El pedido debe tener al menos un producto');
            return;
        }

        setSaving(true);
        try {
            await ordersService.updateOrder(id, {
                items: cart,
                notes,
                paymentMethod,
                total: calculateTotal()
            });

            toast.success('Pedido actualizado exitosamente');
            setTimeout(() => navigate('/lista-pedidos'), 1500);
        } catch (error) {
            toast.error('Error al actualizar el pedido');
            console.error(error);
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return <div className="loading-container"><div className="spinner"></div></div>;
    }

    return (
        <div className="editar-pedido-page">
            <div className="page-header">
                <div>
                    <h1>✏️ Editar Pedido #{id}</h1>
                    <p>Modifica los detalles del pedido</p>
                </div>
                <button onClick={() => navigate('/lista-pedidos')} className="btn-secondary">
                    ← Volver
                </button>
            </div>

            <div className="edit-form">
                {/* Product Search */}
                <div className="form-section">
                    <h2>📦 Agregar Productos</h2>
                    <SearchInput
                        placeholder="Buscar producto..."
                        onSearch={setProductSearch}
                        icon="🔍"
                    />
                    {productResults.length > 0 && (
                        <div className="search-results">
                            {productResults.map(p => (
                                <div
                                    key={p.id}
                                    className="search-result-item"
                                    onClick={() => addToCart(p)}
                                >
                                    <strong>{p.name}</strong>
                                    <span>${p.price.toFixed(2)}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Cart */}
                <div className="form-section">
                    <h2>🛒 Productos del Pedido</h2>
                    {cart.length === 0 ? (
                        <div className="empty-cart">
                            <p>No hay productos en el pedido</p>
                        </div>
                    ) : (
                        <div className="cart-items">
                            {cart.map(item => (
                                <div key={item.productId} className="cart-item">
                                    <div className="item-info">
                                        <strong>{item.name}</strong>
                                        <span>${item.price.toFixed(2)} c/u</span>
                                    </div>
                                    <div className="item-quantity">
                                        <button
                                            onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                            className="qty-btn"
                                        >
                                            -
                                        </button>
                                        <input
                                            type="number"
                                            value={item.quantity}
                                            onChange={(e) => updateQuantity(item.productId, parseInt(e.target.value) || 0)}
                                            className="qty-input"
                                            min="1"
                                        />
                                        <button
                                            onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                                            className="qty-btn"
                                        >
                                            +
                                        </button>
                                    </div>
                                    <div className="item-total">
                                        ${(item.price * item.quantity).toFixed(2)}
                                    </div>
                                    <button
                                        onClick={() => removeFromCart(item.productId)}
                                        className="btn-remove"
                                    >
                                        🗑️
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Payment Details */}
                <div className="form-section">
                    <h2>💳 Detalles de Pago</h2>
                    <div className="payment-details">
                        <div className="form-group">
                            <label>Método de Pago</label>
                            <select
                                value={paymentMethod}
                                onChange={(e) => setPaymentMethod(e.target.value)}
                                className="form-control"
                            >
                                <option value="efectivo">Efectivo</option>
                                <option value="tarjeta">Tarjeta</option>
                                <option value="transferencia">Transferencia</option>
                                <option value="credito">Crédito</option>
                            </select>
                        </div>

                        <div className="form-group full-width">
                            <label>Notas</label>
                            <textarea
                                value={notes}
                                onChange={(e) => setNotes(e.target.value)}
                                className="form-control"
                                rows="3"
                                placeholder="Notas adicionales..."
                            />
                        </div>
                    </div>
                </div>

                {/* Summary */}
                <div className="form-section summary-section">
                    <h2>📊 Resumen</h2>
                    <div className="summary">
                        <div className="summary-row total">
                            <span>Total:</span>
                            <strong>${calculateTotal().toFixed(2)}</strong>
                        </div>
                    </div>
                </div>

                {/* Actions */}
                <div className="form-actions">
                    <button
                        onClick={() => navigate('/lista-pedidos')}
                        className="btn-secondary"
                    >
                        Cancelar
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={saving || cart.length === 0}
                        className="btn-primary"
                    >
                        {saving ? 'Guardando...' : '💾 Guardar Cambios'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default EditarPedido;
