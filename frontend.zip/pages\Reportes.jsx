// Reportes.jsx - Dashboard simplificado (sin Chart.js por ahora)
import React, { useState, useEffect } from 'react';
import { salesService } from '../services/salesService';
import { inventoryService } from '../services/inventoryService';
import { clientsService } from '../services/clientsService';
import { useToast } from '../components/common/Toast';
import './Reportes.css';

const Reportes = () => {
    const toast = useToast();
    const [loading, setLoading] = useState(true);
    const [dateRange, setDateRange] = useState({
        start: new Date(new Date().setDate(1)).toISOString().split('T')[0],
        end: new Date().toISOString().split('T')[0]
    });

    // Data states
    const [salesData, setSalesData] = useState([]);
    const [topProducts, setTopProducts] = useState([]);
    const [topClients, setTopClients] = useState([]);
    const [stats, setStats] = useState({
        totalSales: 0,
        totalRevenue: 0,
        totalOrders: 0,
        averageTicket: 0
    });

    useEffect(() => {
        loadReports();
    }, [dateRange]);

    const loadReports = async () => {
        setLoading(true);
        try {
            // Simular datos
            const mockSales = [
                { id: 1, date: '2024-01-15', total: 150.50, client: 'Cliente A' },
                { id: 2, date: '2024-01-16', total: 200.00, client: 'Cliente B' },
                { id: 3, date: '2024-01-17', total: 175.25, client: 'Cliente C' }
            ];
            setSalesData(mockSales);

            const totalRevenue = mockSales.reduce((sum, sale) => sum + sale.total, 0);
            const totalOrders = mockSales.length;
            const averageTicket = totalOrders > 0 ? totalRevenue / totalOrders : 0;

            setStats({
                totalSales: mockSales.length,
                totalRevenue,
                totalOrders,
                averageTicket
            });

            // Mock data
            setTopProducts([
                { name: 'Producto A', quantitySold: 50, revenue: 500 },
                { name: 'Producto B', quantitySold: 30, revenue: 450 },
                { name: 'Producto C', quantitySold: 25, revenue: 375 }
            ]);

            setTopClients([
                { name: 'Cliente A', purchaseCount: 10, totalSpent: 1500 },
                { name: 'Cliente B', purchaseCount: 8, totalSpent: 1200 },
                { name: 'Cliente C', purchaseCount: 6, totalSpent: 900 }
            ]);

        } catch (error) {
            console.error('Error loading reports:', error);
            toast.error('Error al cargar reportes');
        } finally {
            setLoading(false);
        }
    };

    const exportToExcel = () => {
        toast.info('Exportar a Excel - Función por implementar');
    };

    if (loading) {
        return (
            <div className="loading-container">
                <div className="spinner"></div>
                <p>Cargando reportes...</p>
            </div>
        );
    }

    return (
        <div className="reportes-page">
            <div className="page-header">
                <div>
                    <h1>📊 Reportes y Analytics</h1>
                    <p>Dashboard de ventas y estadísticas</p>
                </div>
                <button onClick={exportToExcel} className="btn-primary">
                    📄 Exportar Excel
                </button>
            </div>

            {/* Filtros de fecha */}
            <div className="filters-section">
                <div className="filter-group">
                    <label>Desde:</label>
                    <input
                        type="date"
                        value={dateRange.start}
                        onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                        className="filter-input"
                    />
                </div>
                <div className="filter-group">
                    <label>Hasta:</label>
                    <input
                        type="date"
                        value={dateRange.end}
                        onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                        className="filter-input"
                    />
                </div>
                <button onClick={loadReports} className="btn-secondary">
                    🔄 Actualizar
                </button>
            </div>

            {/* Estadísticas */}
            <div className="stats-grid">
                <div className="stat-card">
                    <div className="stat-icon">💰</div>
                    <div className="stat-content">
                        <span className="stat-label">Ingresos Totales</span>
                        <span className="stat-value">${stats.totalRevenue.toFixed(2)}</span>
                    </div>
                </div>
                <div className="stat-card">
                    <div className="stat-icon">🛒</div>
                    <div className="stat-content">
                        <span className="stat-label">Total Ventas</span>
                        <span className="stat-value">{stats.totalSales}</span>
                    </div>
                </div>
                <div className="stat-card">
                    <div className="stat-icon">📦</div>
                    <div className="stat-content">
                        <span className="stat-label">Pedidos</span>
                        <span className="stat-value">{stats.totalOrders}</span>
                    </div>
                </div>
                <div className="stat-card">
                    <div className="stat-icon">💵</div>
                    <div className="stat-content">
                        <span className="stat-label">Ticket Promedio</span>
                        <span className="stat-value">${stats.averageTicket.toFixed(2)}</span>
                    </div>
                </div>
            </div>

            {/* Nota sobre gráficos */}
            <div className="info-banner">
                <strong>ℹ️ Nota:</strong> Para habilitar gráficos interactivos, instala las dependencias:
                <code>npm install chart.js react-chartjs-2 jspdf jspdf-autotable</code>
            </div>

            {/* Tablas */}
            <div className="tables-grid">
                <div className="table-card">
                    <h3>Top 10 Productos</h3>
                    <table className="report-table">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Cantidad</th>
                                <th>Ingresos</th>
                            </tr>
                        </thead>
                        <tbody>
                            {topProducts.map((product, index) => (
                                <tr key={index}>
                                    <td>{product.name}</td>
                                    <td>{product.quantitySold}</td>
                                    <td>${product.revenue?.toFixed(2) || '0.00'}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div className="table-card">
                    <h3>Top 10 Clientes</h3>
                    <table className="report-table">
                        <thead>
                            <tr>
                                <th>Cliente</th>
                                <th>Compras</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            {topClients.map((client, index) => (
                                <tr key={index}>
                                    <td>{client.name}</td>
                                    <td>{client.purchaseCount}</td>
                                    <td>${client.totalSpent?.toFixed(2) || '0.00'}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Reportes;
