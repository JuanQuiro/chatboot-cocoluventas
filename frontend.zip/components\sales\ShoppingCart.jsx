// ShoppingCart.jsx - MEJORADO con descuentos, notas y duplicar
import React, { useState } from 'react';
import './ShoppingCart.css';

const ShoppingCart = ({
    items,
    onUpdateQuantity,
    onRemoveItem,
    onUpdatePrice,
    onUpdateDiscount,
    onUpdateNotes,
    onDuplicate,
    getItemPrice,
    dragDrop // ⭐ FASE 1: Drag and drop support
}) => {
    if (items.length === 0) {
        return (
            <div className="empty-cart">
                <p>El carrito está vacío</p>
                <span>Busca productos para agregar</span>
            </div>
        );
    }

    return (
        <div className="cart-items">
            {items.map((item, index) => (
                <CartItem
                    key={item.id}
                    item={item}
                    index={index}
                    onUpdateQuantity={onUpdateQuantity}
                    onRemove={onRemoveItem}
                    onUpdatePrice={onUpdatePrice}
                    onUpdateDiscount={onUpdateDiscount}
                    onUpdateNotes={onUpdateNotes}
                    onDuplicate={onDuplicate}
                    getItemPrice={getItemPrice}
                    dragDrop={dragDrop}
                />
            ))}
        </div>
    );
};

const CartItem = ({
    item,
    index,
    onUpdateQuantity,
    onRemove,
    onUpdatePrice,
    onUpdateDiscount,
    onUpdateNotes,
    onDuplicate,
    getItemPrice,
    dragDrop // ⭐ FASE 1: Drag and drop
}) => {
    const [editingPrice, setEditingPrice] = useState(false);
    const [editingDiscount, setEditingDiscount] = useState(false);
    const [editingNotes, setEditingNotes] = useState(false);
    const [tempPrice, setTempPrice] = useState(item.price);
    const [tempDiscount, setTempDiscount] = useState(item.discount || 0);
    const [tempDiscountType, setTempDiscountType] = useState(item.discountType || 'percentage');
    const [tempNotes, setTempNotes] = useState(item.notes || '');

    const handlePriceChange = () => {
        if (tempPrice > 0 && onUpdatePrice) {
            onUpdatePrice(item.id, tempPrice);
            setEditingPrice(false);
        }
    };

    const handleDiscountChange = () => {
        if (onUpdateDiscount) {
            onUpdateDiscount(item.id, tempDiscount, tempDiscountType);
            setEditingDiscount(false);
        }
    };

    const handleNotesChange = () => {
        if (onUpdateNotes) {
            onUpdateNotes(item.id, tempNotes);
            setEditingNotes(false);
        }
    };

    const finalPrice = getItemPrice ? getItemPrice(item) : item.price;

    return (
        <div
            className="cart-item"
            draggable={dragDrop ? true : false}
            onDragStart={dragDrop ? (e) => dragDrop.handleDragStart(e, index) : undefined}
            onDragOver={dragDrop ? (e) => dragDrop.handleDragOver(e, index) : undefined}
            onDragEnd={dragDrop ? dragDrop.handleDragEnd : undefined}
        >
            <div className="item-main">
                <div className="item-info">
                    <strong>{item.name}</strong>

                    {/* Precio */}
                    {editingPrice ? (
                        <div className="price-edit">
                            <input
                                type="number"
                                step="0.01"
                                value={tempPrice}
                                onChange={(e) => setTempPrice(parseFloat(e.target.value) || 0)}
                                onBlur={handlePriceChange}
                                onKeyPress={(e) => e.key === 'Enter' && handlePriceChange()}
                                className="price-input"
                                autoFocus
                            />
                            <button onClick={handlePriceChange} className="price-save-btn">✓</button>
                        </div>
                    ) : (
                        <span
                            onClick={() => setEditingPrice(true)}
                            className="price-display"
                            title="Click para editar precio"
                        >
                            ${item.price.toFixed(2)} c/u
                        </span>
                    )}

                    {/* ⭐ NUEVO: Descuento individual */}
                    {editingDiscount ? (
                        <div className="discount-edit">
                            <input
                                type="number"
                                step="0.01"
                                value={tempDiscount}
                                onChange={(e) => setTempDiscount(parseFloat(e.target.value) || 0)}
                                className="discount-input"
                                placeholder="Descuento"
                            />
                            <select
                                value={tempDiscountType}
                                onChange={(e) => setTempDiscountType(e.target.value)}
                                className="discount-type-select"
                            >
                                <option value="percentage">%</option>
                                <option value="fixed">$</option>
                            </select>
                            <button onClick={handleDiscountChange} className="discount-save-btn">✓</button>
                        </div>
                    ) : (
                        <span
                            onClick={() => setEditingDiscount(true)}
                            className="discount-display"
                            title="Click para agregar descuento"
                        >
                            {item.discount > 0 ? (
                                `Desc: ${item.discount}${item.discountType === 'percentage' ? '%' : '$'}`
                            ) : (
                                '+ Descuento'
                            )}
                        </span>
                    )}

                    {item.isManual && <span className="manual-badge">Manual</span>}
                </div>

                <div className="item-quantity">
                    <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        className="qty-btn"
                    >
                        -
                    </button>
                    <input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => onUpdateQuantity(item.id, parseInt(e.target.value) || 0)}
                        className="qty-input"
                        min="1"
                    />
                    <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="qty-btn"
                    >
                        +
                    </button>
                </div>

                <div className="item-total">
                    {item.discount > 0 && (
                        <span className="original-total">${(item.price * item.quantity).toFixed(2)}</span>
                    )}
                    <span className="final-total">${(finalPrice * item.quantity).toFixed(2)}</span>
                </div>

                <div className="item-actions">
                    {/* ⭐ NUEVO: Duplicar */}
                    {onDuplicate && (
                        <button
                            type="button"
                            onClick={() => onDuplicate(item.id)}
                            className="btn-duplicate"
                            title="Duplicar producto"
                        >
                            📋
                        </button>
                    )}

                    <button
                        type="button"
                        onClick={() => onRemove(item.id)}
                        className="btn-remove"
                        title="Eliminar"
                    >
                        🗑️
                    </button>
                </div>
            </div>

            {/* ⭐ NUEVO: Notas */}
            <div className="item-notes">
                {editingNotes ? (
                    <div className="notes-edit">
                        <textarea
                            value={tempNotes}
                            onChange={(e) => setTempNotes(e.target.value)}
                            onBlur={handleNotesChange}
                            className="notes-textarea"
                            placeholder="Agregar notas..."
                            rows="2"
                            autoFocus
                        />
                        <button onClick={handleNotesChange} className="notes-save-btn">✓ Guardar</button>
                    </div>
                ) : (
                    <div
                        onClick={() => setEditingNotes(true)}
                        className="notes-display"
                    >
                        {item.notes ? (
                            <span>📝 {item.notes}</span>
                        ) : (
                            <span className="notes-placeholder">+ Agregar notas</span>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default ShoppingCart;
