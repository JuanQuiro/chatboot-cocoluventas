// QuickClientCreate.jsx - Modal para crear cliente rápido
import React, { useState } from 'react';
import Modal from '../common/Modal';
import { useToast } from '../common/Toast';
import { clientsService } from '../../services/clientsService';
import './QuickClientCreate.css';

const QuickClientCreate = ({ isOpen, onClose, onClientCreated }) => {
    const toast = useToast();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: ''
    });

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.name || !formData.phone) {
            toast.error('Nombre y teléfono son obligatorios');
            return;
        }

        setLoading(true);
        try {
            const newClient = await clientsService.quickCreate(formData);
            toast.success('Cliente creado exitosamente');
            onClientCreated(newClient);
            onClose();
            setFormData({ name: '', phone: '', email: '' });
        } catch (error) {
            console.error('Error creating client:', error);
            toast.error('Error al crear cliente');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title="➕ Crear Cliente Rápido"
            size="small"
        >
            <form onSubmit={handleSubmit} className="quick-client-form">
                <p className="form-description">
                    Crea un cliente con información básica. Podrás completar los datos después.
                </p>

                <div className="form-group">
                    <label>Nombre Completo *</label>
                    <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="form-control"
                        placeholder="Ej: Juan Pérez"
                        required
                        autoFocus
                    />
                </div>

                <div className="form-group">
                    <label>Teléfono *</label>
                    <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="form-control"
                        placeholder="Ej: +58 412-1234567"
                        required
                    />
                </div>

                <div className="form-group">
                    <label>Email (opcional)</label>
                    <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="form-control"
                        placeholder="Ej: juan@email.com"
                    />
                </div>

                <div className="modal-actions">
                    <button
                        type="button"
                        onClick={onClose}
                        className="btn-secondary"
                        disabled={loading}
                    >
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        className="btn-primary"
                        disabled={loading}
                    >
                        {loading ? 'Creando...' : '✅ Crear y Seleccionar'}
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default QuickClientCreate;
