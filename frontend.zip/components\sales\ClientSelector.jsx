// ClientSelector.jsx - MEJORADO con navegación por teclado y highlighting
import React, { useRef, useEffect } from 'react';
import useKeyboardNavigation from '../../hooks/useKeyboardNavigation';
import TextHighlighter from '../common/TextHighlighter';
import './ClientSelector.css';

const ClientSelector = ({
    client,
    searchQuery,
    results,
    onSearchChange,
    onSelectClient,
    onClearClient,
    keyboardNav // ⭐ FASE 1: Keyboard navigation
}) => {
    const inputRef = useRef(null);
    const resultsRef = useRef(null);

    // ⭐ NUEVO: Keyboard navigation
    const keyboard = useKeyboardNavigation(results, onSelectClient);

    // Activate keyboard navigation when results appear
    useEffect(() => {
        if (results.length > 0) {
            keyboard.activate();
        } else {
            keyboard.deactivate();
        }
    }, [results]);

    // Scroll selected item into view
    useEffect(() => {
        if (keyboard.selectedIndex >= 0 && resultsRef.current) {
            const selectedElement = resultsRef.current.children[keyboard.selectedIndex];
            if (selectedElement) {
                selectedElement.scrollIntoView({
                    block: 'nearest',
                    behavior: 'smooth'
                });
            }
        }
    }, [keyboard.selectedIndex]);

    if (client) {
        return (
            <div className="selected-client">
                <div className="client-info">
                    <strong>{client.name}</strong>
                    {client.phone && <span className="client-phone">📞 {client.phone}</span>}
                    {client.email && <span className="client-email">✉️ {client.email}</span>}
                </div>
                <button
                    type="button"
                    onClick={onClearClient}
                    className="btn-clear"
                    title="Quitar cliente"
                >
                    ✕
                </button>
            </div>
        );
    }

    return (
        <div className="client-selector">
            <div className="search-container">
                <input
                    ref={inputRef}
                    type="text"
                    value={searchQuery}
                    onChange={(e) => onSearchChange(e.target.value)}
                    placeholder="Buscar cliente por nombre, teléfono o email..."
                    className="search-input"
                    autoComplete="off"
                />
                {searchQuery && (
                    <button
                        type="button"
                        onClick={() => onSearchChange('')}
                        className="btn-clear-search"
                        title="Limpiar búsqueda"
                    >
                        ✕
                    </button>
                )}
            </div>

            {results.length > 0 && (
                <div className="search-results" ref={resultsRef}>
                    {/* ⭐ NUEVO: Keyboard hint */}
                    <div className="keyboard-hint">
                        Use ↑↓ para navegar, Enter para seleccionar, Esc para cerrar
                    </div>

                    {results.map((result, index) => (
                        <div
                            key={result.id}
                            className={`result-item ${keyboard.selectedIndex === index ? 'selected' : ''}`}
                            onClick={() => onSelectClient(result)}
                            onMouseEnter={() => keyboard.setSelectedIndex(index)}
                        >
                            <div className="result-content">
                                <div className="result-name">
                                    {/* ⭐ NUEVO: Text highlighting */}
                                    <TextHighlighter
                                        text={result.name}
                                        highlight={searchQuery}
                                    />
                                </div>
                                {result.phone && (
                                    <div className="result-detail">
                                        📞 <TextHighlighter
                                            text={result.phone}
                                            highlight={searchQuery}
                                        />
                                    </div>
                                )}
                                {result.email && (
                                    <div className="result-detail">
                                        ✉️ <TextHighlighter
                                            text={result.email}
                                            highlight={searchQuery}
                                        />
                                    </div>
                                )}
                            </div>
                            {keyboard.selectedIndex === index && (
                                <span className="selected-indicator">→</span>
                            )}
                        </div>
                    ))}
                </div>
            )}

            {searchQuery && results.length === 0 && (
                <div className="no-results">
                    <p>No se encontraron clientes</p>
                    <small>Intenta con otro término de búsqueda</small>
                </div>
            )}
        </div>
    );
};

export default ClientSelector;
