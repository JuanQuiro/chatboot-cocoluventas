import React, { useState, useEffect } from 'react';
import { accountsService } from '../services/accountsService';
import DataTable from '../components/common/DataTable';
import SearchInput from '../components/common/SearchInput';
import StatusBadge from '../components/common/StatusBadge';
import './CuentasPorCobrar.css';

const CuentasPorCobrar = () => {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('efectivo');
  const [paymentNotes, setPaymentNotes] = useState('');

  useEffect(() => {
    loadAccounts();
  }, [searchQuery]);

  const loadAccounts = async () => {
    setLoading(true);
    try {
      const data = await accountsService.getAccountsReceivable({ search: searchQuery });
      setAccounts(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error loading accounts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterPayment = async (e) => {
    e.preventDefault();
    try {
      await accountsService.registerPayment({
        accountId: selectedAccount.id,
        amount: paymentAmount,
        method: paymentMethod,
        notes: paymentNotes
      });
      alert('Pago registrado exitosamente');
      setShowPaymentForm(false);
      setSelectedAccount(null);
      setPaymentAmount(0);
      setPaymentNotes('');
      loadAccounts();
    } catch (error) {
      console.error('Error registering payment:', error);
      alert('Error al registrar el pago');
    }
  };

  const columns = [
    { key: 'clientName', label: 'Cliente', sortable: true },
    {
      key: 'saleDate',
      label: 'Fecha Venta',
      sortable: true,
      render: (value) => new Date(value).toLocaleDateString()
    },
    {
      key: 'totalAmount',
      label: 'Monto Total',
      sortable: true,
      render: (value) => `$${value?.toFixed(2) || '0.00'}`
    },
    {
      key: 'paidAmount',
      label: 'Pagado',
      sortable: true,
      render: (value) => `$${value?.toFixed(2) || '0.00'}`
    },
    {
      key: 'balance',
      label: 'Saldo',
      sortable: true,
      render: (value) => (
        <span className="balance-amount">${value?.toFixed(2) || '0.00'}</span>
      )
    },
    {
      key: 'dueDate',
      label: 'Vencimiento',
      sortable: true,
      render: (value) => {
        const date = new Date(value);
        const isOverdue = date < new Date();
        return (
          <span className={isOverdue ? 'overdue' : ''}>
            {date.toLocaleDateString()}
          </span>
        );
      }
    },
    {
      key: 'status',
      label: 'Estado',
      render: (value, row) => {
        const isOverdue = new Date(row.dueDate) < new Date() && row.balance > 0;
        return <StatusBadge status={isOverdue ? 'Vencido' : value} />;
      }
    }
  ];

  const renderActions = (account) => (
    <div className="account-actions">
      <button
        onClick={() => {
          setSelectedAccount(account);
          setPaymentAmount(account.balance);
          setShowPaymentForm(true);
        }}
        className="btn-action btn-payment"
        title="Registrar pago"
      >
        💰
      </button>
      <button
        onClick={() => window.location.href = `/accounts/${account.id}/history`}
        className="btn-action btn-view"
        title="Ver historial"
      >
        📋
      </button>
    </div>
  );

  return (
    <div className="cuentas-por-cobrar-page">
      <div className="page-header">
        <div>
          <h1>💰 Cuentas por Cobrar</h1>
          <p>Gestión de pagos pendientes y abonos</p>
        </div>
      </div>

      {showPaymentForm && selectedAccount && (
        <div className="modal-overlay" onClick={() => setShowPaymentForm(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Registrar Pago</h2>
              <button onClick={() => setShowPaymentForm(false)} className="modal-close">✕</button>
            </div>
            <div className="payment-info">
              <p><strong>Cliente:</strong> {selectedAccount.clientName}</p>
              <p><strong>Saldo Pendiente:</strong> ${selectedAccount.balance.toFixed(2)}</p>
            </div>
            <form onSubmit={handleRegisterPayment} className="payment-form">
              <div className="form-group">
                <label>Monto del Pago *</label>
                <input
                  type="number"
                  step="0.01"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(parseFloat(e.target.value))}
                  max={selectedAccount.balance}
                  required
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label>Método de Pago</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="form-control"
                >
                  <option value="efectivo">Efectivo</option>
                  <option value="tarjeta">Tarjeta</option>
                  <option value="transferencia">Transferencia</option>
                </select>
              </div>
              <div className="form-group">
                <label>Notas</label>
                <textarea
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  className="form-control"
                  rows="3"
                />
              </div>
              <div className="form-actions">
                <button type="button" onClick={() => setShowPaymentForm(false)} className="btn-secondary">
                  Cancelar
                </button>
                <button type="submit" className="btn-primary">
                  Registrar Pago
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="filters-section">
        <SearchInput
          placeholder="Buscar por cliente..."
          onSearch={setSearchQuery}
          icon="🔍"
        />
      </div>

      <div className="accounts-stats">
        <div className="stat-card">
          <span className="stat-label">Total Cuentas</span>
          <span className="stat-value">{accounts.length}</span>
        </div>
        <div className="stat-card">
          <span className="stat-label">Vencidas</span>
          <span className="stat-value danger">
            {accounts.filter(a => new Date(a.dueDate) < new Date() && a.balance > 0).length}
          </span>
        </div>
        <div className="stat-card">
          <span className="stat-label">Total por Cobrar</span>
          <span className="stat-value">
            ${accounts.reduce((sum, a) => sum + (a.balance || 0), 0).toFixed(2)}
          </span>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={accounts}
        loading={loading}
        actions={renderActions}
        pagination={true}
        pageSize={15}
      />
    </div>
  );
};

export default CuentasPorCobrar;
