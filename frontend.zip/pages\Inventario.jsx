import React, { useState, useEffect } from 'react';
import { inventoryService } from '../services/inventoryService';
import DataTable from '../components/common/DataTable';
import SearchInput from '../components/common/SearchInput';
import StatusBadge from '../components/common/StatusBadge';
import { useToast } from '../components/common/Toast';
import './Inventario.css';

const Inventario = () => {
    const toast = useToast();
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [showForm, setShowForm] = useState(false);
    const [editingProduct, setEditingProduct] = useState(null);
    const [formData, setFormData] = useState({
        name: '',
        code: '',
        category: '',
        price: 0,
        cost: 0,
        stock: 0,
        minStock: 0,
        description: ''
    });

    useEffect(() => {
        loadProducts();
    }, [searchQuery]);

    const loadProducts = async () => {
        setLoading(true);
        try {
            const data = await inventoryService.getProducts({ search: searchQuery });
            setProducts(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error('Error loading products:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editingProduct) {
                await inventoryService.updateProduct(editingProduct.id, formData);
                alert('Producto actualizado exitosamente');
            } else {
                await inventoryService.createProduct(formData);
                alert('Producto creado exitosamente');
            }
            setShowForm(false);
            setEditingProduct(null);
            setFormData({
                name: '',
                code: '',
                category: '',
                price: 0,
                cost: 0,
                stock: 0,
                minStock: 0,
                description: ''
            });
            loadProducts();
        } catch (error) {
            console.error('Error creating product:', error);
            const msg = error.response?.data?.error?.message || error.response?.data?.error || error.message;
            toast.error('Error al guardar el producto: ' + msg);
        }
    };

    const handleEdit = (product) => {
        setEditingProduct(product);
        setFormData({
            name: product.name || '',
            code: product.code || '',
            category: product.category || '',
            categoryId: product.categoryId || null,
            price: product.price || 0,
            cost: product.cost || 0,
            stock: product.stock || 0,
            minStock: product.minStock || 0,
            description: product.description || ''
        });
        setShowForm(true);
    };

    const handleDelete = async (productId) => {
        if (!window.confirm('¿Estás seguro de eliminar este producto?')) {
            return;
        }
        try {
            await inventoryService.deleteProduct(productId);
            alert('Producto eliminado exitosamente');
            loadProducts();
        } catch (error) {
            console.error('Error deleting product:', error);
            alert('Error al eliminar el producto');
        }
    };

    const columns = [
        { key: 'code', label: 'Código', sortable: true },
        { key: 'name', label: 'Nombre', sortable: true },
        { key: 'category', label: 'Categoría', sortable: true },
        {
            key: 'price',
            label: 'Precio',
            sortable: true,
            render: (value) => `$${value?.toFixed(2) || '0.00'}`
        },
        {
            key: 'stock',
            label: 'Stock',
            sortable: true,
            render: (value, row) => (
                <span className={value <= row.minStock ? 'stock-low' : 'stock-ok'}>
                    {value}
                </span>
            )
        },
        {
            key: 'minStock',
            label: 'Stock Mín.',
            sortable: true
        }
    ];

    const renderActions = (product) => (
        <div className="product-actions">
            <button
                onClick={() => handleEdit(product)}
                className="btn-action btn-edit"
                title="Editar"
            >
                ✏️
            </button>
            <button
                onClick={() => handleDelete(product.id)}
                className="btn-action btn-delete"
                title="Eliminar"
            >
                🗑️
            </button>
        </div>
    );

    const generateRandomCode = () => {
        return 'PRD-' + Math.random().toString(36).substring(2, 8).toUpperCase();
    };

    return (
        <div className="inventario-page">
            <div className="page-header">
                <div>
                    <h1>📦 Inventario</h1>
                    <p>Gestión completa de productos</p>
                </div>
                <button
                    onClick={() => {
                        setShowForm(true);
                        setEditingProduct(null);
                        setFormData({
                            name: '',
                            code: generateRandomCode(), // Auto-generate code
                            category: '',
                            categoryId: null,
                            price: 0,
                            cost: 0,
                            stock: 0,
                            minStock: 0,
                            description: ''
                        });
                    }}
                    className="btn-primary"
                >
                    ➕ Nuevo Producto
                </button>
            </div>

            {
                showForm && (
                    <div className="modal-overlay" onClick={() => setShowForm(false)}>
                        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                            <div className="modal-header">
                                <h2>{editingProduct ? 'Editar Producto' : 'Nuevo Producto'}</h2>
                                <button onClick={() => setShowForm(false)} className="modal-close">✕</button>
                            </div>
                            <form onSubmit={handleSubmit} className="product-form">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Código *</label>
                                        <input
                                            type="text"
                                            value={formData.code}
                                            onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                                            required
                                            className="form-control"
                                            disabled
                                            style={{ backgroundColor: '#e9ecef', cursor: 'not-allowed' }}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Nombre *</label>
                                        <input
                                            type="text"
                                            value={formData.name}
                                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                            required
                                            className="form-control"
                                        />
                                    </div>
                                </div>

                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Categoría</label>
                                        <input
                                            type="text"
                                            value={formData.category}
                                            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                                            className="form-control"
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Precio *</label>
                                        <input
                                            type="number"
                                            step="0.01"
                                            value={formData.price}
                                            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                                            required
                                            className="form-control"
                                        />
                                    </div>
                                </div>

                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Costo</label>
                                        <input
                                            type="number"
                                            step="0.01"
                                            value={formData.cost}
                                            onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                                            className="form-control"
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Stock *</label>
                                        <input
                                            type="number"
                                            value={formData.stock}
                                            onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                                            required
                                            className="form-control"
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Stock Mínimo</label>
                                        <input
                                            type="number"
                                            value={formData.minStock}
                                            onChange={(e) => setFormData({ ...formData, minStock: e.target.value })}
                                            className="form-control"
                                        />
                                    </div>
                                </div>

                                <div className="form-group">
                                    <label>Descripción</label>
                                    <textarea
                                        value={formData.description}
                                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                        className="form-control"
                                        rows="3"
                                    />
                                </div>

                                <div className="form-actions">
                                    <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">
                                        Cancelar
                                    </button>
                                    <button type="submit" className="btn-primary">
                                        {editingProduct ? 'Actualizar' : 'Crear'} Producto
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )
            }

            <div className="filters-section">
                <SearchInput
                    placeholder="Buscar por nombre, código o categoría..."
                    onSearch={setSearchQuery}
                    icon="🔍"
                />
            </div>

            <div className="inventory-stats">
                <div className="stat-card">
                    <span className="stat-label">Total Productos</span>
                    <span className="stat-value">{products.length}</span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Stock Bajo</span>
                    <span className="stat-value warning">
                        {products.filter(p => p.stock <= p.minStock).length}
                    </span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Valor Inventario</span>
                    <span className="stat-value">
                        ${products.reduce((sum, p) => sum + (p.price * p.stock), 0).toFixed(2)}
                    </span>
                </div>
            </div>

            <DataTable
                columns={columns}
                data={products}
                loading={loading}
                actions={renderActions}
                pagination={true}
                pageSize={15}
            />
        </div >
    );
};

export default Inventario;
