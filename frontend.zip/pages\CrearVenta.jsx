// CrearVenta.jsx - VERSIÓN COMPLETA CON TODOS LOS HOOKS INTEGRADOS
import React, { useState, useEffect } from 'react';
import { salesService } from '../services/salesService';
import { inventoryService } from '../services/inventoryService';
import SearchInput from '../components/common/SearchInput';
import Modal from '../components/common/Modal';
import { useToast } from '../components/common/Toast';

// Custom Hooks - TODOS INTEGRADOS
import useClientSearch from '../hooks/useClientSearch';
import useShoppingCart from '../hooks/useShoppingCart';
import useSaleCalculations from '../hooks/useSaleCalculations';
import useAutoSave from '../hooks/useAutoSave';
import useStockValidation from '../hooks/useStockValidation';
import useInstallmentSystem from '../hooks/useInstallmentSystem';
// ⭐ NUEVOS HOOKS FASE 1
import useKeyboardNavigation from '../hooks/useKeyboardNavigation';
import useClientValidation from '../hooks/useClientValidation';
import useMixedPayment from '../hooks/useMixedPayment';
import useDragAndDrop from '../hooks/useDragAndDrop';
import useUndoRedo from '../hooks/useUndoRedo';
import useCartTemplates from '../hooks/useCartTemplates';
import useBarcodeScanner from '../hooks/useBarcodeScanner';
import useInfiniteScroll from '../hooks/useInfiniteScroll';
import usePerformance from '../hooks/usePerformance';

// Specialized Components
import ClientSelector from '../components/sales/ClientSelector';
import ShoppingCart from '../components/sales/ShoppingCart';
import SaleConfiguration from '../components/sales/SaleConfiguration';
import SaleSummary from '../components/sales/SaleSummary';
import InstallmentConfiguration from '../components/sales/InstallmentConfiguration';
import QuickClientCreate from '../components/sales/QuickClientCreate';
// ⭐ NUEVOS COMPONENTES FASE 1
import ValidationMessages from '../components/common/ValidationMessages';
import AnimatedCard from '../components/common/AnimatedCard';
import Tooltip from '../components/common/Tooltip';
import Skeleton from '../components/common/Skeleton';

import './CrearVenta.css';

const CrearVenta = () => {
    const toast = useToast();

    // Custom hooks para lógica de negocio
    const clientSearch = useClientSearch();
    const cart = useShoppingCart();
    const calculations = useSaleCalculations(cart.calculateSubtotal());

    // ⭐ NUEVO: Stock validation hook
    const stockValidation = useStockValidation();

    // ⭐ NUEVO: Installment system hook
    const installmentSystem = useInstallmentSystem(calculations.calculateTotal());

    // ⭐ FASE 1: Client validation hook
    const clientValidation = useClientValidation();

    // ⭐ FASE 1: Mixed payment hook
    const mixedPayment = useMixedPayment(calculations.calculateTotal());

    // ⭐ FASE 1: Performance hook
    const performance = usePerformance();

    // ⭐ FASE 1: Keyboard navigation for client search
    const keyboardNav = useKeyboardNavigation(clientSearch.results, (client) => {
        clientSearch.selectClient(client);
    });

    // ⭐ FASE 1: Drag and drop for cart items
    const dragDrop = useDragAndDrop(cart.cart, (reorderedItems) => {
        // Reorder cart items
        cart.cart = reorderedItems;
    });

    // ⭐ FASE 1: Undo/Redo for cart
    const undoRedo = useUndoRedo(cart.cart);

    // ⭐ FASE 1: Cart templates
    const cartTemplates = useCartTemplates();

    // ⭐ FASE 1: Barcode scanner
    const barcodeScanner = useBarcodeScanner((barcode) => {
        // Search product by barcode
        inventoryService.searchByBarcode(barcode)
            .then(product => {
                if (product) {
                    handleAddProduct(product);
                }
            });
    });

    // Product search state - MOVED BEFORE infiniteScroll
    const [productSearch, setProductSearch] = useState('');
    const [productResults, setProductResults] = useState([]);
    const [loadingProducts, setLoadingProducts] = useState(false); // ⭐ FASE 2

    // ⭐ FASE 1: Infinite scroll for product results
    const infiniteScroll = useInfiniteScroll(() => {
        // Load more products
        return inventoryService.loadMoreProducts();
    }, productResults.length < 100);

    // Payment state
    const [paymentType, setPaymentType] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('efectivo');
    const [mixedPaymentUSD, setMixedPaymentUSD] = useState(0);
    const [mixedPaymentVES, setMixedPaymentVES] = useState(0);
    const [exchangeRate, setExchangeRate] = useState(36.5);

    // Manual product modal
    const [showManualProduct, setShowManualProduct] = useState(false);
    const [showQuickClient, setShowQuickClient] = useState(false);
    const [manualProduct, setManualProduct] = useState({
        name: '',
        price: 0,
        quantity: 1
    });

    const [notes, setNotes] = useState('');
    const [loading, setLoading] = useState(false);

    // ⭐ NUEVO: Auto-save data preparation
    const autoSaveData = {
        client: clientSearch.client,
        cart: cart.cart,
        paymentType,
        paymentMethod,
        mixedPaymentUSD,
        mixedPaymentVES,
        hasDelivery: calculations.hasDelivery,
        deliveryAmount: calculations.deliveryAmount,
        hasIVA: calculations.hasIVA,
        hasDiscount: calculations.hasDiscount,
        discountType: calculations.discountType,
        discountValue: calculations.discountValue,
        notes,
        installmentConfig: installmentSystem.installmentConfig
    };

    // ⭐ NUEVO: Verificar si hay datos significativos para guardar
    const hasContent = Boolean(
        clientSearch.client ||
        (cart.cart && cart.cart.length > 0) ||
        (notes && notes.trim().length > 0)
    );

    // ⭐ NUEVO: Auto-save hook (guardado cada 30s) - Solo habilitado si hay contenido
    const { loadDraft, clearDraft, hasDraft } = useAutoSave(autoSaveData, hasContent);

    // ⭐ NUEVO: Recuperar borrador al montar
    useEffect(() => {
        if (hasDraft()) {
            const draft = loadDraft();

            // Validar que el borrador tenga contenido real antes de preguntar
            const hasDraftContent = draft && (
                draft.client ||
                (draft.cart && draft.cart.length > 0) ||
                (draft.notes && draft.notes.trim().length > 0)
            );

            if (hasDraftContent) {
                toast.custom('¿Deseas recuperar el borrador guardado anteriormente?', {
                    duration: 10000,
                    actions: [
                        {
                            label: 'Sí, recuperar',
                            primary: true,
                            onClick: () => {
                                // Restaurar datos
                                if (draft.client) clientSearch.selectClient(draft.client);
                                if (draft.cart) {
                                    draft.cart.forEach(item => cart.addItem(item));
                                }
                                setPaymentType(draft.paymentType || '');
                                setPaymentMethod(draft.paymentMethod || 'efectivo');
                                setMixedPaymentUSD(draft.mixedPaymentUSD || 0);
                                setMixedPaymentVES(draft.mixedPaymentVES || 0);
                                calculations.setHasDelivery(draft.hasDelivery || false);
                                calculations.setDeliveryAmount(draft.deliveryAmount || 0);
                                calculations.setHasIVA(draft.hasIVA || false);
                                calculations.setHasDiscount(draft.hasDiscount || false);
                                calculations.setDiscountType(draft.discountType || 'percentage');
                                calculations.setDiscountValue(draft.discountValue || 0);
                                setNotes(draft.notes || '');

                                toast.success('✅ Borrador recuperado');
                            }
                        },
                        {
                            label: 'No, descartar',
                            secondary: true,
                            onClick: () => {
                                clearDraft();
                                toast.info('Borrador descartado');
                            }
                        }
                    ]
                });
            } else {
                // Si el borrador está vacío (basura), limpiarlo silenciosamente
                clearDraft();
            }
        }
    }, []); // Solo al montar

    // Product search with debounce - ⭐ FASE 4
    useEffect(() => {
        if (productSearch.length >= 2) {
            setLoadingProducts(true);
            const debouncedSearch = performance.debounce(() => {
                inventoryService.searchProducts(productSearch)
                    .then(results => {
                        setProductResults(results);
                        setLoadingProducts(false);
                    })
                    .catch(err => {
                        console.error('Error searching products:', err);
                        setLoadingProducts(false);
                    });
            }, 300);
            debouncedSearch();
        } else {
            setProductResults([]);
            setLoadingProducts(false);
        }
    }, [productSearch]);

    // ⭐ FASE 1: Validar cliente cuando se selecciona
    useEffect(() => {
        if (clientSearch.client) {
            clientValidation.validateClient(
                clientSearch.client.id,
                calculations.calculateTotal()
            );
        } else {
            clientValidation.clearValidation();
        }
    }, [clientSearch.client, calculations.calculateTotal()]);

    // ⭐ NUEVO: Agregar producto con validación de stock
    const handleAddProduct = async (product) => {
        // Validar stock disponible
        const validation = await stockValidation.validateQuantity(product.id, 1);

        if (!validation.isValid) {
            toast.error(validation.message);
            return;
        }

        cart.addItem(product);
        toast.success(`${product.name} agregado al carrito`);
        setProductSearch('');
        setProductResults([]);
    };

    // ⭐ NUEVO: Actualizar precio de producto
    const handleUpdatePrice = (productId, newPrice) => {
        const item = cart.cart.find(i => i.id === productId);
        if (item) {
            cart.updateItem(productId, { ...item, price: newPrice });
            toast.success('Precio actualizado');
        }
    };

    const addManualProduct = () => {
        if (!manualProduct.name || manualProduct.price <= 0) {
            toast.error('Complete los datos del producto');
            return;
        }

        const newProduct = {
            id: `manual-${Date.now()}`,
            name: manualProduct.name,
            price: manualProduct.price,
            quantity: manualProduct.quantity,
            isManual: true
        };

        cart.addItem(newProduct);
        setShowManualProduct(false);
        setManualProduct({ name: '', price: 0, quantity: 1 });
        toast.success('Producto manual agregado');
    };

    // ⭐ NUEVO: Callback para cliente creado rápidamente
    const handleClientCreated = (newClient) => {
        clientSearch.selectClient(newClient);
        toast.success('Cliente creado y seleccionado');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!clientSearch.client) {
            toast.error('Por favor selecciona un cliente');
            return;
        }

        if (cart.cart.length === 0) {
            toast.error('El carrito está vacío');
            return;
        }

        if (!paymentType) {
            toast.error('Selecciona un tipo de pago');
            return;
        }

        setLoading(true);

        try {
            const saleData = {
                clientId: clientSearch.client.id,
                items: cart.cart.map(item => ({
                    productId: item.id,
                    quantity: item.quantity,
                    price: item.price,
                    isManual: item.isManual || false
                })),
                paymentType,
                paymentMethod,
                hasDelivery: calculations.hasDelivery,
                deliveryAmount: calculations.deliveryAmount,
                hasIVA: calculations.hasIVA,
                hasDiscount: calculations.hasDiscount,
                discountType: calculations.discountType,
                discountValue: calculations.discountValue,
                mixedPaymentUSD: paymentType === 'mixto' ? mixedPaymentUSD : 0,
                mixedPaymentVES: paymentType === 'mixto' ? mixedPaymentVES : 0,
                exchangeRate,
                notes,
                subtotal: cart.calculateSubtotal(),
                discount: calculations.calculateDiscount(),
                iva: calculations.calculateIVA(),
                total: calculations.calculateTotal()
            };

            // ⭐ NUEVO: Si es abono, agregar plan de cuotas
            if (paymentType === 'abono' && installmentSystem.installmentSchedule.length > 0) {
                saleData.installmentPlan = {
                    initialPayment: installmentSystem.installmentConfig.initialPayment,
                    numberOfInstallments: installmentSystem.installmentConfig.numberOfInstallments,
                    frequency: installmentSystem.installmentConfig.frequency,
                    startDate: installmentSystem.installmentConfig.startDate,
                    schedule: installmentSystem.installmentSchedule
                };
            }

            const createdSale = await salesService.createSale(saleData);

            // ⭐ NUEVO: Si hay plan de cuotas, crearlo
            if (saleData.installmentPlan) {
                await salesService.createInstallmentPlan(createdSale.id, saleData.installmentPlan);
            }

            toast.success('¡Venta creada exitosamente!');

            // Reset form
            clientSearch.clearClient();
            cart.clearCart();
            setPaymentType('');
            setPaymentMethod('efectivo');
            calculations.setHasDelivery(false);
            calculations.setDeliveryAmount(0);
            calculations.setHasIVA(false);
            calculations.setHasDiscount(false);
            calculations.setDiscountValue(0);
            setMixedPaymentUSD(0);
            setMixedPaymentVES(0);
            setNotes('');
            installmentSystem.disableInstallments();

            // ⭐ NUEVO: Limpiar borrador después de guardar
            clearDraft();
        } catch (error) {
            console.error('Error creating sale:', error);
            toast.error('Error al crear la venta: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="crear-venta-page">
            <div className="page-header">
                <div>
                    <h1>🛒 Crear Nueva Venta</h1>
                    <p>Sistema completo con auto-guardado, validación de stock y plan de cuotas</p>
                </div>
                {/* ⭐ NUEVO: Botón limpiar borrador */}
                {hasDraft() && (
                    <button
                        type="button"
                        onClick={() => {
                            clearDraft();
                            toast.info('Borrador eliminado');
                        }}
                        className="btn-secondary btn-sm"
                    >
                        🗑️ Limpiar Borrador
                    </button>
                )}
            </div>

            <form onSubmit={handleSubmit} className="venta-form">
                {/* Client Selection */}
                <AnimatedCard delay={0.1}>
                    <div className="form-section">
                        <h2>👤 Cliente</h2>
                        <ClientSelector
                            client={clientSearch.client}
                            searchQuery={clientSearch.searchQuery}
                            results={clientSearch.results}
                            onSearchChange={clientSearch.setSearchQuery}
                            onSelectClient={clientSearch.selectClient}
                            onClearClient={clientSearch.clearClient}
                            keyboardNav={keyboardNav}
                        />
                        {/* ⭐ NUEVO: Botón crear cliente rápido */}
                        {!clientSearch.client && clientSearch.searchQuery && clientSearch.results.length === 0 && (
                            <button
                                type="button"
                                onClick={() => setShowQuickClient(true)}
                                className="btn-secondary btn-sm"
                                style={{ marginTop: '8px' }}
                            >
                                ➕ Crear Cliente Rápido
                            </button>
                        )}
                    </div>
                </AnimatedCard>

                {/* ⭐ FASE 1: Mostrar mensajes de validación del cliente */}
                {clientSearch.client && (clientValidation.validationState.errors.length > 0 || clientValidation.validationState.warnings.length > 0) && (
                    <ValidationMessages
                        errors={clientValidation.validationState.errors}
                        warnings={clientValidation.validationState.warnings}
                    />
                )}

                {/* Product Search */}
                <AnimatedCard delay={0.2}>
                    <div className="form-section">
                        {/* ⭐ FASE 3: Barcode scanner indicator */}
                        {barcodeScanner.isScanning && (
                            <div className="barcode-indicator" style={{
                                padding: '8px 12px',
                                background: '#e3f2fd',
                                border: '1px solid #2196f3',
                                borderRadius: '4px',
                                marginBottom: '12px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px'
                            }}>
                                <span>🔍</span>
                                <span>Escaneando: {barcodeScanner.barcode || '...'}</span>
                            </div>
                        )}

                        <div className="section-header">
                            <h2>📦 Productos</h2>
                            <button
                                type="button"
                                onClick={() => setShowManualProduct(true)}
                                className="btn-secondary btn-sm"
                            >
                                ➕ Producto Manual
                            </button>
                        </div>

                        <SearchInput
                            value={productSearch}
                            onChange={setProductSearch}
                            placeholder="Buscar productos..."
                        />

                        {productResults.length > 0 && (
                            <div className="search-results">
                                {productResults.map(product => (
                                    <div
                                        key={product.id}
                                        className="search-result-item"
                                        onClick={() => handleAddProduct(product)}
                                    >
                                        <div className="product-info">
                                            <strong>{product.name}</strong>
                                            <span>${product.price.toFixed(2)}</span>
                                            {/* ⭐ NUEVO: Mostrar stock */}
                                            <span className="stock-badge">
                                                Stock: {product.stock || 0}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </AnimatedCard>

                {/* Shopping Cart */}
                <AnimatedCard delay={0.3}>
                    <div className="form-section">
                        <div className="section-header">
                            <h2>🛒 Carrito</h2>

                            {/* ⭐ FASE 1: Botones de plantillas y undo/redo */}
                            <div className="cart-actions">
                                <Tooltip content="Guardar carrito como plantilla">
                                    <button
                                        type="button"
                                        onClick={() => {
                                            const name = prompt('💾 Nombre de la plantilla:');
                                            if (name && cart.cart.length > 0) {
                                                cartTemplates.saveTemplate(cart.cart, name);
                                                toast.success(`Plantilla "${name}" guardada`);
                                            }
                                        }}
                                        className="btn-secondary btn-sm"
                                        disabled={cart.cart.length === 0}
                                    >
                                        💾 Guardar Plantilla
                                    </button>
                                </Tooltip>

                                <Tooltip content="Cargar plantilla guardada">
                                    <button
                                        type="button"
                                        onClick={() => {
                                            const templates = cartTemplates.templates;
                                            if (templates.length === 0) {
                                                toast.info('No hay plantillas guardadas');
                                                return;
                                            }
                                            const templateNames = templates.map((t, i) => `${i + 1}. ${t.name}`).join('\n');
                                            const selection = prompt(`📋 Plantillas disponibles:\n${templateNames}\n\nIngresa el número:`);
                                            const index = parseInt(selection) - 1;
                                            if (index >= 0 && index < templates.length) {
                                                cartTemplates.loadTemplate(templates[index].id);
                                                cart.clearCart();
                                                templates[index].items.forEach(item => cart.addItem(item));
                                                toast.success(`Plantilla "${templates[index].name}" cargada`);
                                            }
                                        }}
                                        className="btn-secondary btn-sm"
                                    >
                                        📋 Cargar Plantilla
                                    </button>
                                </Tooltip>

                                <Tooltip content="Deshacer (Ctrl+Z)">
                                    <button
                                        type="button"
                                        onClick={undoRedo.undo}
                                        disabled={!undoRedo.canUndo}
                                        className="btn-secondary btn-sm"
                                    >
                                        ↶ Deshacer
                                    </button>
                                </Tooltip>

                                <Tooltip content="Rehacer (Ctrl+Y)">
                                    <button
                                        type="button"
                                        onClick={undoRedo.redo}
                                        disabled={!undoRedo.canRedo}
                                        className="btn-secondary btn-sm"
                                    >
                                        ↷ Rehacer
                                    </button>
                                </Tooltip>
                            </div>
                        </div>

                        <ShoppingCart
                            items={cart.cart}
                            onUpdateQuantity={cart.updateQuantity}
                            onRemoveItem={cart.removeItem}
                            onUpdatePrice={handleUpdatePrice}
                            dragDrop={dragDrop}
                        />
                    </div>
                </AnimatedCard>

                {/* Sale Configuration */}
                <div className="form-section">
                    <h2>⚙️ Configuración</h2>
                    <SaleConfiguration
                        hasDelivery={calculations.hasDelivery}
                        deliveryAmount={calculations.deliveryAmount}
                        hasIVA={calculations.hasIVA}
                        hasDiscount={calculations.hasDiscount}
                        discountType={calculations.discountType}
                        discountValue={calculations.discountValue}
                        onDeliveryChange={calculations.setHasDelivery}
                        onDeliveryAmountChange={calculations.setDeliveryAmount}
                        onIVAChange={calculations.setHasIVA}
                        onDiscountChange={calculations.setHasDiscount}
                        onDiscountTypeChange={calculations.setDiscountType}
                        onDiscountValueChange={calculations.setDiscountValue}
                    />
                </div>

                {/* Payment Type */}
                <div className="form-section">
                    <h2>💳 Tipo de Pago</h2>
                    <select
                        value={paymentType}
                        onChange={(e) => {
                            setPaymentType(e.target.value);
                            if (e.target.value === 'abono') {
                                installmentSystem.enableInstallments(0);
                            } else {
                                installmentSystem.disableInstallments();
                            }
                        }}
                        className="form-control"
                        required
                    >
                        <option value="">Seleccionar...</option>
                        <option value="contado">Contado</option>
                        <option value="credito">Crédito</option>
                        <option value="abono">Abono</option>
                        <option value="mixto">Pago Mixto</option>
                    </select>
                </div>

                {/* ⭐ NUEVO: Installment Configuration */}
                {paymentType === 'abono' && (
                    <div className="form-section">
                        <InstallmentConfiguration
                            totalAmount={calculations.calculateTotal()}
                            installmentConfig={installmentSystem.installmentConfig}
                            onConfigChange={installmentSystem.updateConfig}
                            onGenerateSchedule={installmentSystem.generateInstallmentSchedule}
                            installmentSchedule={installmentSystem.installmentSchedule}
                        />
                    </div>
                )}

                {/* Mixed Payment */}
                {paymentType === 'mixto' && (
                    <div className="form-section">
                        <h3>Pago Mixto (USD + VES)</h3>
                        <div className="mixed-payment-grid">
                            <div className="form-group">
                                <label>Monto USD</label>
                                <input
                                    type="number"
                                    step="0.01"
                                    value={mixedPaymentUSD}
                                    onChange={(e) => setMixedPaymentUSD(parseFloat(e.target.value) || 0)}
                                    className="form-control"
                                />
                            </div>
                            <div className="form-group">
                                <label>Monto VES</label>
                                <input
                                    type="number"
                                    step="0.01"
                                    value={mixedPaymentVES}
                                    onChange={(e) => setMixedPaymentVES(parseFloat(e.target.value) || 0)}
                                    className="form-control"
                                />
                            </div>
                        </div>
                    </div>
                )}

                {/* Notes */}
                <div className="form-section">
                    <h2>📝 Notas</h2>
                    <textarea
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="form-control"
                        rows="3"
                        placeholder="Notas adicionales..."
                    />
                </div>

                {/* Summary */}
                <SaleSummary
                    subtotal={cart.calculateSubtotal()}
                    delivery={calculations.hasDelivery ? calculations.deliveryAmount : 0}
                    discount={calculations.calculateDiscount()}
                    iva={calculations.calculateIVA()}
                    total={calculations.calculateTotal()}
                />

                {/* Submit Button */}
                <div className="form-actions">
                    <button
                        type="submit"
                        className="btn-primary btn-lg"
                        disabled={loading}
                    >
                        {loading ? 'Guardando...' : '💾 Crear Venta'}
                    </button>
                </div>
            </form>

            {/* Modals */}
            <Modal
                isOpen={showManualProduct}
                onClose={() => setShowManualProduct(false)}
                title="Agregar Producto Manual"
            >
                <div className="manual-product-form">
                    <div className="form-group">
                        <label>Nombre del Producto</label>
                        <input
                            type="text"
                            value={manualProduct.name}
                            onChange={(e) => setManualProduct({ ...manualProduct, name: e.target.value })}
                            className="form-control"
                        />
                    </div>
                    <div className="form-group">
                        <label>Precio</label>
                        <input
                            type="number"
                            step="0.01"
                            value={manualProduct.price}
                            onChange={(e) => setManualProduct({ ...manualProduct, price: parseFloat(e.target.value) || 0 })}
                            className="form-control"
                        />
                    </div>
                    <div className="form-group">
                        <label>Cantidad</label>
                        <input
                            type="number"
                            value={manualProduct.quantity}
                            onChange={(e) => setManualProduct({ ...manualProduct, quantity: parseInt(e.target.value) || 1 })}
                            className="form-control"
                        />
                    </div>
                    <button onClick={addManualProduct} className="btn-primary">
                        Agregar
                    </button>
                </div>
            </Modal>

            {/* ⭐ NUEVO: Quick Client Create Modal */}
            <QuickClientCreate
                isOpen={showQuickClient}
                onClose={() => setShowQuickClient(false)}
                onClientCreated={handleClientCreated}
            />
        </div>
    );
};

export default CrearVenta;
