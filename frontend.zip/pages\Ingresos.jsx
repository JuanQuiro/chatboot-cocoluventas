import React, { useState, useEffect } from 'react';
import { incomeService } from '../services/accountsService';
import DataTable from '../components/common/DataTable';
import SearchInput from '../components/common/SearchInput';
import Modal from '../components/common/Modal';
import { useToast } from '../components/common/Toast';
import './Ingresos.css';

const Ingresos = () => {
    const [incomes, setIncomes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [editingIncome, setEditingIncome] = useState(null);
    const [formData, setFormData] = useState({
        description: '',
        amount: 0,
        category: '',
        date: new Date().toISOString().split('T')[0],
        notes: ''
    });
    const [dateRange, setDateRange] = useState({ start: '', end: '' });
    const toast = useToast();

    useEffect(() => {
        loadIncomes();
    }, [searchQuery, dateRange]);

    const loadIncomes = async () => {
        setLoading(true);
        try {
            const filters = {
                search: searchQuery,
                startDate: dateRange.start || undefined,
                endDate: dateRange.end || undefined
            };
            const data = await incomeService.getIncome(filters);
            setIncomes(Array.isArray(data) ? data : []);
        } catch (error) {
            toast.error('Error al cargar ingresos');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async () => {
        try {
            if (editingIncome) {
                await incomeService.updateIncome(editingIncome.id, formData);
                toast.success('Ingreso actualizado');
            } else {
                await incomeService.createIncome(formData);
                toast.success('Ingreso registrado');
            }
            setShowModal(false);
            setEditingIncome(null);
            setFormData({
                description: '',
                amount: 0,
                category: '',
                date: new Date().toISOString().split('T')[0],
                notes: ''
            });
            loadIncomes();
        } catch (error) {
            toast.error('Error al guardar ingreso');
            console.error(error);
        }
    };

    const handleEdit = (income) => {
        setEditingIncome(income);
        setFormData(income);
        setShowModal(true);
    };

    const handleDelete = async (id) => {
        if (!window.confirm('¿Eliminar este ingreso?')) return;
        try {
            await incomeService.deleteIncome(id);
            toast.success('Ingreso eliminado');
            loadIncomes();
        } catch (error) {
            toast.error('Error al eliminar');
            console.error(error);
        }
    };

    const columns = [
        {
            key: 'date',
            label: 'Fecha',
            sortable: true,
            render: (value) => new Date(value).toLocaleDateString()
        },
        {
            key: 'description',
            label: 'Descripción',
            sortable: true
        },
        {
            key: 'category',
            label: 'Categoría',
            sortable: true
        },
        {
            key: 'amount',
            label: 'Monto',
            sortable: true,
            render: (value) => `$${value?.toFixed(2) || '0.00'}`
        },
        {
            key: 'notes',
            label: 'Notas',
            render: (value) => value || '-'
        }
    ];

    const renderActions = (income) => (
        <div className="income-actions">
            <button onClick={() => handleEdit(income)} className="btn-action btn-edit">✏️</button>
            <button onClick={() => handleDelete(income.id)} className="btn-action btn-delete">🗑️</button>
        </div>
    );

    return (
        <div className="ingresos-page">
            <div className="page-header">
                <div>
                    <h1>💰 Ingresos</h1>
                    <p>Gestión de ingresos y reportes</p>
                </div>
                <button onClick={() => setShowModal(true)} className="btn-primary">
                    ➕ Nuevo Ingreso
                </button>
            </div>

            <div className="filters-section">
                <SearchInput placeholder="Buscar..." onSearch={setSearchQuery} icon="🔍" />
                <div className="filter-group">
                    <label>Desde:</label>
                    <input
                        type="date"
                        value={dateRange.start}
                        onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                        className="filter-input"
                    />
                </div>
                <div className="filter-group">
                    <label>Hasta:</label>
                    <input
                        type="date"
                        value={dateRange.end}
                        onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                        className="filter-input"
                    />
                </div>
            </div>

            <div className="income-stats">
                <div className="stat-card">
                    <span className="stat-label">Total Ingresos</span>
                    <span className="stat-value">{incomes.length}</span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Monto Total</span>
                    <span className="stat-value success">
                        ${incomes.reduce((sum, i) => sum + (i.amount || 0), 0).toFixed(2)}
                    </span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Promedio</span>
                    <span className="stat-value">
                        ${incomes.length > 0 ? (incomes.reduce((sum, i) => sum + (i.amount || 0), 0) / incomes.length).toFixed(2) : '0.00'}
                    </span>
                </div>
            </div>

            <DataTable
                columns={columns}
                data={incomes}
                loading={loading}
                actions={renderActions}
                pagination={true}
                pageSize={15}
            />

            <Modal
                isOpen={showModal}
                onClose={() => setShowModal(false)}
                title={editingIncome ? 'Editar Ingreso' : 'Nuevo Ingreso'}
                size="medium"
            >
                <div className="income-form">
                    <div className="form-group">
                        <label>Descripción *</label>
                        <input
                            type="text"
                            value={formData.description}
                            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                            className="form-control"
                            required
                        />
                    </div>

                    <div className="form-row">
                        <div className="form-group">
                            <label>Monto *</label>
                            <input
                                type="number"
                                step="0.01"
                                value={formData.amount}
                                onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) })}
                                className="form-control"
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Fecha *</label>
                            <input
                                type="date"
                                value={formData.date}
                                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                                className="form-control"
                                required
                            />
                        </div>
                    </div>

                    <div className="form-group">
                        <label>Categoría</label>
                        <select
                            value={formData.category}
                            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                            className="form-control"
                        >
                            <option value="">Seleccionar...</option>
                            <option value="Ventas">Ventas</option>
                            <option value="Servicios">Servicios</option>
                            <option value="Otros">Otros</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label>Notas</label>
                        <textarea
                            value={formData.notes}
                            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                            className="form-control"
                            rows="3"
                        />
                    </div>

                    <div className="modal-actions">
                        <button onClick={() => setShowModal(false)} className="btn-secondary">
                            Cancelar
                        </button>
                        <button onClick={handleSubmit} className="btn-primary">
                            {editingIncome ? 'Actualizar' : 'Crear'}
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default Ingresos;
