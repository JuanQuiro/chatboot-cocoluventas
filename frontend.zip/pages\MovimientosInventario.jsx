import React, { useState, useEffect } from 'react';
import { inventoryService } from '../services/inventoryService';
import DataTable from '../components/common/DataTable';
import SearchInput from '../components/common/SearchInput';
import './MovimientosInventario.css';

const MovimientosInventario = () => {
    const [movements, setMovements] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [typeFilter, setTypeFilter] = useState('all');
    const [dateRange, setDateRange] = useState({ start: '', end: '' });

    useEffect(() => {
        loadMovements();
    }, [searchQuery, typeFilter, dateRange]);

    const loadMovements = async () => {
        setLoading(true);
        try {
            const filters = {
                search: searchQuery,
                type: typeFilter !== 'all' ? typeFilter : undefined,
                startDate: dateRange.start || undefined,
                endDate: dateRange.end || undefined
            };

            const data = await inventoryService.getMovements(filters);
            // Ensure data is always an array
            setMovements(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error('Error loading movements:', error);
            setMovements([]); // Set empty array on error
        } finally {
            setLoading(false);
        }
    };

    const columns = [
        {
            key: 'date',
            label: 'Fecha',
            sortable: true,
            render: (value) => new Date(value).toLocaleDateString()
        },
        {
            key: 'product',
            label: 'Producto',
            sortable: true,
            render: (value) => value?.name || 'N/A'
        },
        {
            key: 'type',
            label: 'Tipo',
            sortable: true,
            render: (value) => {
                const types = {
                    'entrada': '📥 Entrada',
                    'salida': '📤 Salida',
                    'ajuste': '⚙️ Ajuste',
                    'devolucion': '↩️ Devolución'
                };
                return types[value] || value;
            }
        },
        {
            key: 'quantity',
            label: 'Cantidad',
            sortable: true,
            render: (value, row) => (
                <span className={row.type === 'salida' ? 'quantity-negative' : 'quantity-positive'}>
                    {row.type === 'salida' ? '-' : '+'}{value}
                </span>
            )
        },
        {
            key: 'previousStock',
            label: 'Stock Anterior',
            sortable: true
        },
        {
            key: 'newStock',
            label: 'Stock Nuevo',
            sortable: true
        },
        {
            key: 'user',
            label: 'Usuario',
            render: (value) => value?.name || 'Sistema'
        },
        {
            key: 'notes',
            label: 'Notas',
            render: (value) => value || '-'
        }
    ];

    return (
        <div className="movimientos-inventario-page">
            <div className="page-header">
                <div>
                    <h1>📊 Movimientos de Inventario</h1>
                    <p>Historial completo de movimientos de stock</p>
                </div>
            </div>

            <div className="filters-section">
                <SearchInput
                    placeholder="Buscar por producto..."
                    onSearch={setSearchQuery}
                    icon="🔍"
                />

                <div className="filter-group">
                    <label>Tipo:</label>
                    <select
                        value={typeFilter}
                        onChange={(e) => setTypeFilter(e.target.value)}
                        className="filter-select"
                    >
                        <option value="all">Todos</option>
                        <option value="entrada">Entrada</option>
                        <option value="salida">Salida</option>
                        <option value="ajuste">Ajuste</option>
                        <option value="devolucion">Devolución</option>
                    </select>
                </div>

                <div className="filter-group">
                    <label>Desde:</label>
                    <input
                        type="date"
                        value={dateRange.start}
                        onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                        className="filter-input"
                    />
                </div>

                <div className="filter-group">
                    <label>Hasta:</label>
                    <input
                        type="date"
                        value={dateRange.end}
                        onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                        className="filter-input"
                    />
                </div>
            </div>

            <div className="movements-stats">
                <div className="stat-card">
                    <span className="stat-label">Total Movimientos</span>
                    <span className="stat-value">{movements.length}</span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Entradas</span>
                    <span className="stat-value success">
                        {movements.filter(m => m.type === 'entrada').length}
                    </span>
                </div>
                <div className="stat-card">
                    <span className="stat-label">Salidas</span>
                    <span className="stat-value danger">
                        {movements.filter(m => m.type === 'salida').length}
                    </span>
                </div>
            </div>

            <DataTable
                columns={columns}
                data={movements}
                loading={loading}
                pagination={true}
                pageSize={20}
            />
        </div>
    );
};

export default MovimientosInventario;
